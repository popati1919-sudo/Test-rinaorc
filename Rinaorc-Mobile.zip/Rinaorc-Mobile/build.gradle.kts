// Versions cohérentes : AGP 8.7.3 exige Gradle >= 8.9 (on utilise 8.10.2) et JDK 17.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
