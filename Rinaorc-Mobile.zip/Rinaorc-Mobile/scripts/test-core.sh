#!/usr/bin/env bash
# Compile et teste core/common avec le seul JDK (aucun SDK Android requis).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT

javac -encoding UTF-8 -d "$OUT" \
  "$ROOT"/core/common/src/main/java/com/rinaorc/mobile/common/*.java \
  "$ROOT"/core/common/src/test/java/com/rinaorc/mobile/common/*.java

java -cp "$OUT" com.rinaorc.mobile.common.OfflineAccountCheck
