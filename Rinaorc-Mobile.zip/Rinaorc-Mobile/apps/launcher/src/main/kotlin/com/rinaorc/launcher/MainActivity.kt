package com.rinaorc.launcher

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rinaorc.mobile.common.LaunchRequest
import com.rinaorc.mobile.common.OfflineAccount

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = AccountStore(applicationContext)
        setContent {
            RinaorcTheme {
                var account by remember { mutableStateOf(store.load()) }
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(RinaorcColors.Background)
                        .statusBarsPadding()
                ) {
                    val current = account
                    if (current == null) {
                        LoginScreen(onLogin = { store.save(it); account = it })
                    } else {
                        HomeScreen(current, onLogout = { store.clear(); account = null })
                    }
                }
            }
        }
    }
}

@Composable
private fun Brand() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Le logo officiel (rinaorc.com/assets/logo/logo.webp) n'est pas encore intégré.
        Box(
            Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(RinaorcColors.Accent),
            contentAlignment = Alignment.Center
        ) {
            Text("R", color = RinaorcColors.OnAccent, fontSize = 36.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(12.dp))
        Text("Rinaorc", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
private fun LoginScreen(onLogin: (OfflineAccount) -> Unit) {
    var pseudo by remember { mutableStateOf("") }
    var touched by remember { mutableStateOf(false) }
    val error = if (touched) OfflineAccount.usernameError(pseudo) else null

    fun submit() {
        touched = true
        if (OfflineAccount.isValidUsername(pseudo)) onLogin(OfflineAccount.create(pseudo))
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Brand()
        Spacer(Modifier.height(40.dp))

        OutlinedTextField(
            value = pseudo,
            onValueChange = { pseudo = it.trim(); touched = true },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Pseudo") },
            singleLine = true,
            isError = error != null,
            supportingText = { Text(error ?: "3 à 16 caractères : lettres, chiffres et _") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { submit() }),
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { submit() },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = RinaorcColors.Accent,
                contentColor = RinaorcColors.OnAccent
            )
        ) {
            Text("Continuer avec un pseudo", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        // Volontairement désactivé : la connexion Microsoft officielle demande une
        // application enregistrée sur Azure (identifiant client) qui n'existe pas encore.
        OutlinedButton(
            onClick = {},
            enabled = false,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("Compte Microsoft (bientôt)")
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "Pas besoin de compte Minecraft premium : ton pseudo suffit pour rejoindre Rinaorc.",
            color = RinaorcColors.TextSecondary,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun HomeScreen(account: OfflineAccount, onLogout: () -> Unit) {
    val context: Context = LocalContext.current
    val logs = remember { mutableStateListOf("Connecté en mode hors-ligne : ${account.username}") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Brand()
        Spacer(Modifier.height(28.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(RinaorcColors.Surface)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(RinaorcColors.Accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        account.username.first().uppercase(),
                        color = RinaorcColors.OnAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(account.username, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Compte hors-ligne", color = RinaorcColors.TextSecondary, fontSize = 13.sp)
                }
                TextButton(onClick = onLogout) { Text("Changer") }
            }
            Spacer(Modifier.height(14.dp))
            Text("Serveur : ${LaunchRequest.DEFAULT_SERVER}", color = RinaorcColors.TextSecondary, fontSize = 14.sp)
            Text("Version : ${LaunchRequest.DEFAULT_VERSION}", color = RinaorcColors.TextSecondary, fontSize = 14.sp)
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                logs += EngineLauncher.launch(
                    context, account, LaunchRequest.DEFAULT_VERSION, LaunchRequest.DEFAULT_SERVER
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = RinaorcColors.Accent,
                contentColor = RinaorcColors.OnAccent
            )
        ) {
            Text("JOUER", fontSize = 18.sp, fontWeight = FontWeight.Black)
        }

        Spacer(Modifier.height(24.dp))
        Text("Journal", fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(RinaorcColors.Surface)
                .padding(12.dp)
        ) {
            logs.forEach { Text(it, color = RinaorcColors.TextSecondary, fontSize = 13.sp) }
        }
    }
}
