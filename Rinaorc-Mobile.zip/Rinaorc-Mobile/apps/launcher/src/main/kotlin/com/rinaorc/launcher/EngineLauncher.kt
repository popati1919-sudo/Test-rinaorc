package com.rinaorc.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import com.rinaorc.mobile.common.LaunchRequest
import com.rinaorc.mobile.common.OfflineAccount

/** Envoie la demande de lancement à Rinaorc Engine et renvoie une ligne de journal. */
object EngineLauncher {

    fun launch(context: Context, account: OfflineAccount, version: String, server: String): String {
        // Intent explicite : seul le paquet de l'Engine peut le recevoir.
        val intent = Intent(LaunchRequest.ACTION)
            .setPackage(LaunchRequest.ENGINE_PACKAGE)
            .putExtra(LaunchRequest.EXTRA_USERNAME, account.username)
            .putExtra(LaunchRequest.EXTRA_UUID, account.uuid.toString())
            .putExtra(LaunchRequest.EXTRA_ACCESS_TOKEN, account.accessToken)
            .putExtra(LaunchRequest.EXTRA_VERSION, version)
            .putExtra(LaunchRequest.EXTRA_SERVER, server)

        return try {
            context.startActivity(intent)
            "Demande envoyée à Rinaorc Engine ($version → $server)."
        } catch (e: ActivityNotFoundException) {
            "Rinaorc Engine n'est pas installé : impossible de lancer Minecraft."
        } catch (e: SecurityException) {
            "Rinaorc Engine a refusé la demande : ${e.message}"
        }
    }
}
