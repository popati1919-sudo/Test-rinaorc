package com.rinaorc.launcher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object RinaorcColors {
    val Background = Color(0xFF171527) // couleur de thème publiée par rinaorc.com
    val Surface = Color(0xFF221F3A)    // choix de design : variante plus claire du fond
    val Accent = Color(0xFFF5B93A)     // choix de design : doré, comme le bouton Jouer du site
    val OnAccent = Color(0xFF1A1400)
    val TextSecondary = Color(0xFFB4B0CC)
    val Error = Color(0xFFFF6B6B)
}

private val scheme = darkColorScheme(
    primary = RinaorcColors.Accent,
    onPrimary = RinaorcColors.OnAccent,
    background = RinaorcColors.Background,
    onBackground = Color.White,
    surface = RinaorcColors.Surface,
    onSurface = Color.White,
    error = RinaorcColors.Error,
)

@Composable
fun RinaorcTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
