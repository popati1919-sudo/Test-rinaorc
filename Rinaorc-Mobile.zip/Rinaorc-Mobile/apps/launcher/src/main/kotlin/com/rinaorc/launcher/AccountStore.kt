package com.rinaorc.launcher

import android.content.Context
import com.rinaorc.mobile.common.OfflineAccount

/**
 * Mémorise le pseudo choisi. Seul le pseudo est stocké : l'UUID hors-ligne en est
 * déduit à chaque fois, il n'y a ni mot de passe ni jeton à protéger.
 */
class AccountStore(context: Context) {

    private val prefs = context.getSharedPreferences("rinaorc_account", Context.MODE_PRIVATE)

    fun load(): OfflineAccount? {
        val name = prefs.getString(KEY_USERNAME, null) ?: return null
        return if (OfflineAccount.isValidUsername(name)) OfflineAccount.create(name) else null
    }

    fun save(account: OfflineAccount) {
        prefs.edit().putString(KEY_USERNAME, account.username).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_USERNAME).apply()
    }

    private companion object {
        const val KEY_USERNAME = "username"
    }
}
