package com.rinaorc.mobile.common;

import java.util.UUID;

/** Tests sans dépendance : lancer avec scripts/test-core.sh. */
public final class OfflineAccountCheck {

    private static int failures = 0;

    private static void check(String name, boolean ok) {
        System.out.println((ok ? "OK   " : "FAIL ") + name);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        // Pseudos valides
        check("Steve valide", OfflineAccount.isValidUsername("Steve"));
        check("3 caractères valide", OfflineAccount.isValidUsername("abc"));
        check("16 caractères valide", OfflineAccount.isValidUsername("a234567890123456"));
        check("underscore valide", OfflineAccount.isValidUsername("Rina_orc_1"));

        // Pseudos invalides
        check("null refusé", !OfflineAccount.isValidUsername(null));
        check("vide refusé", !OfflineAccount.isValidUsername(""));
        check("2 caractères refusé", !OfflineAccount.isValidUsername("ab"));
        check("17 caractères refusé", !OfflineAccount.isValidUsername("a2345678901234567"));
        check("espace refusé", !OfflineAccount.isValidUsername("Mon Pseudo"));
        check("accent refusé", !OfflineAccount.isValidUsername("Éric"));
        check("tiret refusé", !OfflineAccount.isValidUsername("a-b-c"));

        // UUID hors-ligne
        UUID notch = OfflineAccount.offlineUuid("Notch");
        System.out.println("     UUID hors-ligne de Notch = " + notch);
        check("UUID Notch = valeur Minecraft connue",
                notch.toString().equals("b50ad385-829d-3141-a216-7e7d7539ba7f"));
        check("UUID de version 3", notch.version() == 3);
        check("UUID stable", OfflineAccount.offlineUuid("Steve").equals(OfflineAccount.offlineUuid("Steve")));
        check("UUID sensible à la casse", !OfflineAccount.offlineUuid("Steve").equals(OfflineAccount.offlineUuid("steve")));

        // create()
        OfflineAccount a = OfflineAccount.create("Steve");
        check("create : pseudo", a.getUsername().equals("Steve"));
        check("create : jeton hors-ligne", a.getAccessToken().equals("0"));
        boolean threw = false;
        try {
            OfflineAccount.create("pas valide!");
        } catch (IllegalArgumentException e) {
            threw = true;
            System.out.println("     message d'erreur : " + e.getMessage());
        }
        check("create refuse un pseudo invalide", threw);

        System.out.println(failures == 0 ? "\nTous les tests passent." : "\n" + failures + " test(s) en échec.");
        System.exit(failures == 0 ? 0 : 1);
    }
}
