package com.rinaorc.mobile.common;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Compte "sans Microsoft" : un simple pseudo.
 *
 * L'UUID est calculé comme le fait le client Minecraft Java en mode hors-ligne :
 * UUID v3 (MD5) de la chaîne "OfflinePlayer:" + pseudo. Un même pseudo donne donc
 * toujours le même UUID, et le serveur retrouve le même joueur à chaque connexion.
 */
public final class OfflineAccount {

    public static final int MIN_LENGTH = 3;
    public static final int MAX_LENGTH = 16;

    /** Un jeton d'accès hors-ligne n'est pas vérifié par le serveur ; Minecraft attend "0". */
    public static final String OFFLINE_ACCESS_TOKEN = "0";

    private static final Pattern VALID = Pattern.compile("[A-Za-z0-9_]{" + MIN_LENGTH + "," + MAX_LENGTH + "}");

    private final String username;
    private final UUID uuid;

    private OfflineAccount(String username, UUID uuid) {
        this.username = username;
        this.uuid = uuid;
    }

    /** @return un message d'erreur en français, ou {@code null} si le pseudo est valide. */
    public static String usernameError(String username) {
        if (username == null || username.isEmpty()) {
            return "Entre un pseudo.";
        }
        if (username.length() < MIN_LENGTH) {
            return "Le pseudo doit faire au moins " + MIN_LENGTH + " caractères.";
        }
        if (username.length() > MAX_LENGTH) {
            return "Le pseudo doit faire au plus " + MAX_LENGTH + " caractères.";
        }
        if (!VALID.matcher(username).matches()) {
            return "Seuls les lettres, chiffres et _ sont autorisés.";
        }
        return null;
    }

    public static boolean isValidUsername(String username) {
        return usernameError(username) == null;
    }

    public static UUID offlineUuid(String username) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
    }

    /** @throws IllegalArgumentException si le pseudo est invalide (message en français). */
    public static OfflineAccount create(String username) {
        String error = usernameError(username);
        if (error != null) {
            throw new IllegalArgumentException(error);
        }
        return new OfflineAccount(username, offlineUuid(username));
    }

    public String getUsername() {
        return username;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getAccessToken() {
        return OFFLINE_ACCESS_TOKEN;
    }
}
