package com.rinaorc.mobile.common;

/**
 * Contrat entre Rinaorc Launcher et Rinaorc Engine.
 *
 * Le Launcher envoie un intent explicite (setPackage) à l'Engine avec ces extras.
 * L'Engine devra vérifier la signature du Launcher avant d'accepter la demande ; ce
 * contrôle n'existe pas encore (l'Engine n'est pas écrit).
 */
public final class LaunchRequest {

    private LaunchRequest() {}

    public static final String ENGINE_PACKAGE = "com.rinaorc.engine";
    public static final String ACTION = "com.rinaorc.engine.action.LAUNCH";

    public static final String EXTRA_USERNAME = "username";
    public static final String EXTRA_UUID = "uuid";
    public static final String EXTRA_ACCESS_TOKEN = "access_token";
    public static final String EXTRA_VERSION = "version";
    public static final String EXTRA_SERVER = "server";

    public static final String DEFAULT_SERVER = "rinaorc.com";
    /** Version demandée dans le cahier des charges ; non vérifiée auprès de Mojang. */
    public static final String DEFAULT_VERSION = "26.3-snapshot-1";
}
