# Rinaorc Mobile

## État réel du projet

| Élément | État |
|---|---|
| Rinaorc Launcher : connexion par pseudo, écran d'accueil, bouton Jouer | **Code écrit, non compilé, non testé sur téléphone** |
| `core/common` : validation du pseudo, UUID hors-ligne | **Compilé et testé** (20 tests, `scripts/test-core.sh`) |
| Connexion Microsoft | Bouton désactivé : il faut enregistrer une application Azure (identifiant client) |
| Rinaorc Engine (Amethyst, LWJGL, Java, rendu) | **Non commencé** |
| Rinaorc Control | **Non commencé** |
| Minecraft 26.3-snapshot-1 sur Galaxy S21 | **Non testé.** Aucun lancement n'a eu lieu. |
| Connexion au serveur Rinaorc | **Non testée** |

Le Launcher envoie une demande à `com.rinaorc.engine`. Tant que l'Engine n'existe pas,
le bouton **Jouer** écrit simplement dans le journal « Rinaorc Engine n'est pas installé ».

## Connexion sans compte Microsoft

Le Launcher demande un pseudo (3 à 16 caractères : lettres, chiffres, `_`). L'UUID est calculé
comme le fait Minecraft en mode hors-ligne : UUID v3 de `OfflinePlayer:<pseudo>`.
Vérifié : `Notch` donne `b50ad385-829d-3141-a216-7e7d7539ba7f`.

La page rinaorc.com/en/launcher indique que le serveur accepte de jouer « avec un simple pseudo ».
Le Launcher s'appuie sur cette indication ; elle n'a pas été testée avec une vraie connexion.

## Compiler l'APK

Le SDK Android n'a pas pu être installé dans l'environnement de développement (téléchargement refusé), donc
**aucun APK n'a été produit**. Trois options :

1. **GitHub Actions (conseillé depuis Termux)** : pousse ce dossier sur un dépôt GitHub, onglet *Actions* →
   *Build Rinaorc Launcher APK* → *Run workflow*. L'APK est dans les artefacts du run.
2. **Android Studio** sur PC : ouvrir le dossier, laisser Gradle synchroniser, *Build → Build APK(s)*.
3. **Ligne de commande** avec JDK 17, Android SDK (platform 35) et Gradle 8.10.2 :
   `gradle :apps:launcher:assembleDebug`

L'APK sort dans `apps/launcher/build/outputs/apk/debug/`.

Versions : Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26.
Ces versions sont cohérentes entre elles d'après la documentation, mais n'ont pas été vérifiées par une
vraie compilation.

## Tester la logique du pseudo

    ./scripts/test-core.sh

Ne demande que le JDK.

## À faire

- Logo officiel (`rinaorc.com/assets/logo/logo.webp`) et icône d'application.
- Engine : étudier Amethyst-Android (le dépôt n'a pas été récupéré), puis intégrer.
- Vérifier la signature du Launcher côté Engine avant d'accepter une demande.
- Connexion Microsoft officielle.
- Control.
